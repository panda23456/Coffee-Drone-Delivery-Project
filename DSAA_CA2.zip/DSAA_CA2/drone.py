import turtle

class Drone:
    def __init__(self, start_position, city_map, destination_callback=None):
        self.position = start_position
        self.city_map = city_map
        self.path_index = 0
        self.path = []
        self.paused = False
        self.isAutoPilotOn = False  # Add isAutoPilotOn attribute
        self.reachedEnd = False
        self.destination_callback = destination_callback
        
        self.turtle = turtle.Turtle()
        self.turtle.color('black', 'red')
        self.turtle.shapesize(stretch_wid=2, stretch_len=2)
        self.turtle.penup()
        self.turtle.setheading(90)  # Set turtle to facing up as default
        self.update_position()

    def update_position(self):
        TILE_SIZE = 50
        x = self.position[0] * TILE_SIZE - (self.city_map.cols // 2) * TILE_SIZE + TILE_SIZE / 2
        y = (self.city_map.rows // 2) * TILE_SIZE - self.position[1] * TILE_SIZE - TILE_SIZE / 2
        self.turtle.goto(x, y)

    def move_up(self):
        if self.isAutoPilotOn:
            return
        self.turtle.setheading(90)
        self.move(0, -1)

    def move_down(self):
        if self.isAutoPilotOn:
            return
        self.turtle.setheading(270)
        self.move(0, 1)

    def move_left(self):
        if self.isAutoPilotOn:
            return
        self.turtle.setheading(180)
        self.move(-1, 0)

    def move_right(self):
        if self.isAutoPilotOn:
            return
        self.turtle.setheading(0)
        self.move(1, 0)

    def move(self, dx, dy):
        new_position = (self.position[0] + dx, self.position[1] + dy)
        if self.is_valid_position(new_position):
            self.position = new_position
            self.update_position()

    def is_valid_position(self, position):
        if position[0] < 0 or position[0] >= len(self.city_map.grid[0]):
            return False
        if position[1] < 0 or position[1] >= len(self.city_map.grid):
            return False
        return self.city_map.grid[position[1]][position[0]] not in ['X', 'bird']


    def follow_path(self, path, display_status, destination_callback=None):
        self.path = path
        self.path_index = 0
        self.display_status = display_status
        self.isAutoPilotOn = True
        self.destination_callback = destination_callback  # Store the callback function
        self.follow_next_step()

    def follow_next_step(self):
        if self.paused or not self.isAutoPilotOn:
            return  # If paused, do nothing
        if self.path_index < len(self.path):
            next_position = self.path[self.path_index]
            self.rotate_towards(next_position)
            self.position = next_position
            self.update_position()
            self.path_index += 1
            turtle.ontimer(self.follow_next_step, 500)
        else:
            self.display_status(f"Automatic Pilot: Destination {self.position} reached in {len(self.path)-1} steps. Press ‘c’ to continue.")
            self.reachedEnd = True
            if self.destination_callback:
                self.destination_callback()  # Notify callback function

    def rotate_towards(self, next_position):
        current_x, current_y = self.position
        next_x, next_y = next_position

        if next_x > current_x:
            self.turtle.setheading(0)  # East
        elif next_x < current_x:
            self.turtle.setheading(180)  # West
        elif next_y > current_y:
            self.turtle.setheading(270)  # North
        elif next_y < current_y:
            self.turtle.setheading(90)  # South

    def resume_path(self):
        self.paused = False
        if self.path_index < len(self.path):
            self.follow_next_step()

    def pause(self):
        self.paused = True

    def reset_position(self, position):
        self.position = position
        self.update_position()

    def get_position(self):
        return self.position
    
