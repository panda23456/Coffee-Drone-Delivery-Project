import turtle
from citymap import CityMap
from drone import Drone
from player_mode import PlayerMode
# from data_structures import deque
import time

class Activator:
    def __init__(self, map_file):
        self.city_map = CityMap(map_file)
        self.drone = None
        self.path = []
        self.status_message = turtle.Turtle()
        self.status_message.hideturtle()
        self.status_message.penup()
        self.autopilot = False
        self.paused = False
        # self.path_toggle_enabled = True  # Flag to control path visibility toggle
        self.movement_delay = True 
        self.f_delay = True
        self.g_delay = True
        self.h_delay = True
        self.p_delay = True
        self.c_delay = True
        self.r_delay = True
        self.x_delay= True

        # Dictionary to track enabled keys
        self.key_state = {
            "Up": False,
            "Down": False,
            "Left": False,
            "Right": False,
            "f": False,
            "g": False,
            "h": False,
            "p": False,
            "c": False,
            "r": True,
            "q": True,
            'x':True
        }

    def run(self):
        self.city_map.draw_map()
        start_position = self.city_map.get_start_position()
        if start_position:
            self.drone = Drone(start_position, self.city_map)
            self.display_status("Manual Mode: Use arrow keys to navigate (press ‘f’ to calculate shortest path)")
            self.enable_initial_keys()
            self.setup_key_bindings()
            turtle.mainloop()
        else:
            self.display_status("No start position found in the map.")

    def enable_initial_keys(self):
        self.key_state.update({
            "Up": True,
            "Down": True,
            "Left": True,
            "Right": True,
            "f": True,
            'x': True
        })

    def setup_key_bindings(self):
        screen = turtle.Screen()
        screen.listen()

        # Arrow key bindings
        screen.onkey(lambda: self.check_key("Up", self.drone.move_up), "Up")
        screen.onkey(lambda: self.check_key("Down", self.drone.move_down), "Down")
        screen.onkey(lambda: self.check_key("Left", self.drone.move_left), "Left")
        screen.onkey(lambda: self.check_key("Right", self.drone.move_right), "Right")

        # Other key bindings
        screen.onkey(lambda: self.check_key("f", self.start_autopilot), "f")
        screen.onkey(lambda: self.check_key("g", self.follow_path), "g")
        screen.onkey(lambda: self.check_key("h", self.toggle_path_visibility), "h")
        screen.onkey(lambda: self.check_key("p", self.toggle_pause), "p")
        screen.onkey(lambda: self.check_key("c", self.continue_manual), "c")
        screen.onkey(lambda: self.check_key("r", self.reset_drone), "r")
        screen.onkey(lambda: self.check_key("x", self.activate_player_mode), "x")
        screen.onkey(turtle.bye, "q")

    def check_key(self, key, function):
        if self.key_state.get(key, False):
            function()

    def display_status(self, message):
        TILE_SIZE = 50
        grid_width = self.city_map.cols * TILE_SIZE
        grid_height = self.city_map.rows * TILE_SIZE
        status_x = -grid_width // 2
        status_y = grid_height // 2 + 40

        self.status_message.clear()
        self.status_message.goto(status_x, status_y)
        self.status_message.write('COFFEE~GO~DRONE: Done by Shaun Kwo & Yip Khai DAAA/2A/03', font=("Arial", 16, "normal"))
        self.status_message.goto(status_x, status_y - 30)
        self.status_message.write(message, font=("Arial", 12, "normal"))

    def start_autopilot(self):
        if self.f_delay:
            self.f_delay = False  # Disable further toggles until function completes

            self.lock_reset()
            self.drone.isAutoPilotOn = True
            self.path = self.calculate_path(self.city_map.grid, self.drone.position, self.city_map.get_end_position())
            if self.path:
                for (x, y) in self.path:
                    self.city_map.draw_path_circle((x - self.city_map.cols // 2) * 50 + 25, (self.city_map.rows // 2 - y) * 50 - 25)
                self.display_status("Automatic Pilot: Press ‘g’ to follow pre-calculated path.")
                self.key_state.update({"f": False, "g": True, "h": True})
                self.unlock_reset()
            else:
                self.display_status("No valid path found. Please use a valid map: Press 'q' to quit")
                self.key_state.update({
                    "Up": False,
                    "Down": False,
                    "Left": False,
                    "Right": False,
                    "f": False,
                    "g": False,
                    "h": False,
                    "p": False,
                    "c": False,
                    "r": False
                })

            # Enable path visibility toggle again after a short delay or operation completion
            turtle.ontimer(lambda: self.disable_delay('f_delay', True), 500)  # 500 milliseconds delay (adjust as needed)

    def lock_reset(self):
        self.key_state.update({"r": False})

    def unlock_reset(self):
        self.key_state.update({"r": True})

    def calculate_path(self, grid, start, end):
        # Check if the endpoint is blocked
        if grid[end[1]][end[0]] == 'X':
            return None
        
        class Queue:
            def __init__(self):
                self.items = []

            def is_empty(self):
                return len(self.items) == 0

            def enqueue(self, item):
                self.items.append(item)

            def dequeue(self):
                if self.is_empty():
                    raise IndexError("dequeue from an empty queue")
                return self.items.pop(0)

            def size(self):
                return len(self.items)
            
        # Define Queue
        queue = Queue()
        queue.enqueue(start)

        # Create a dictionary to keep track of visited nodes and their previous node
        visited = {start: None}

        # Continue until there are no more nodes to visit
        while not queue.is_empty():
            # Dequeue the next node to process
            current = queue.dequeue()
            
            # If the current node is the end position, exit the loop
            if current == end:
                break

            # Iterate over the possible movement directions (up, right, down, left)
            for direction in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
                # Calculate the neighbor node's position
                neighbor = (current[0] + direction[0], current[1] + direction[1])
                
                # Check if the neighbor is within the grid boundaries, is not blocked, and has not been visited
                if (0 <= neighbor[0] < len(grid[0]) and 0 <= neighbor[1] < len(grid) and 
                    grid[neighbor[1]][neighbor[0]] != 'X' and neighbor not in visited):
                    # Enqueue the valid neighbor
                    queue.enqueue(neighbor)
                    # Mark the neighbor as visited and store its previous node
                    visited[neighbor] = current

        # Initialize an empty list to build the path
        path = []
        # Start from the end position and trace back to the start using the visited dictionary
        step = end
        while step:
            path.append(step)
            step = visited.get(step)
        # Reverse the path to get the correct order from start to end
        path.reverse()
        
        # Check if the path is valid (i.e., reaches the start point)
        if not path or path[0] != start:
            return None

        # Return the valid path from start to end
        return path


    def follow_path(self):
        if self.g_delay:
            self.g_delay = False  # Disable further toggles until function completes

            self.lock_reset()
            self.drone.follow_path(self.path, self.display_status, self.destination_reached)
            self.display_status("Automatic Pilot: Following pre-calculated path. Press ‘p’ to toggle pause/resume.")
            self.key_state.update({"g": False, "p": True})

            # Enable path visibility toggle again after a short delay or operation completion
            turtle.ontimer(lambda: self.disable_delay('g_delay', True), 500)  # 500 milliseconds delay (adjust as needed)

    def destination_reached(self):
        self.unlock_reset()
        self.key_state.update({"p": False, "c": True, "r": False})  # Unlock 'c' key and lock 'p' key

    def toggle_pause(self):
        if self.p_delay:
            self.p_delay = False  # Disable further toggles until function completes

            self.paused = not self.paused
            if self.paused:
                self.unlock_reset()
                self.display_status("Automatic Pilot: Paused. Press ‘p’ to resume.")
                self.drone.pause()
            else:
                self.lock_reset()
                self.display_status("Automatic Pilot: Following pre-calculated path. Press ‘p’ to toggle pause/resume.")
                self.drone.resume_path()

            # Enable path visibility toggle again after a short delay or operation completion
            turtle.ontimer(lambda: self.disable_delay('p_delay', True), 500)  # 500 milliseconds delay (adjust as needed)

    def continue_manual(self):
        if self.c_delay:
            self.c_delay = False  # Disable further toggles until function completes

            self.autopilot = False
            self.drone.isAutoPilotOn = False
            self.path = []
            self.city_map.clear_path()  # Erase path circles
            self.display_status("Manual Mode: Use arrow keys to navigate (press ‘f’ to calculate shortest path)")
            self.key_state.update({
                    "Up": True,
                    "Down": True,
                    "Left": True,
                    "Right": True,
                    "f": True,
                    "g": False,
                    "h": False,
                    "p": False,
                    "c": False,
                    "r": True
                })
            
            # Enable path visibility toggle again after a short delay or operation completion
            turtle.ontimer(lambda: self.disable_delay('c_delay', True), 500)  # 500 milliseconds delay (adjust as needed)

    def reset_drone(self):
        if not self.paused:
            self.drone.pause()
        if self.r_delay:
            self.r_delay = False  # Disable further toggles until function completes
        
            self.autopilot = False
            self.paused = False
            self.path = []
            self.city_map.clear_path()  # Erase path circles
            start_position = self.city_map.get_start_position()
            if start_position:
                self.drone.reset_position(start_position)
                self.drone.turtle.setheading(90)
                self.drone.isAutoPilotOn = False
                self.drone.paused = False
                self.display_status("Manual Mode: Use arrow keys to navigate (press ‘f’ to calculate shortest path)")
                self.key_state.update({
                    "Up": True,
                    "Down": True,
                    "Left": True,
                    "Right": True,
                    "f": True,
                    "g": False,
                    "h": False,
                    "p": False,
                    "c": False,
                    "r": True
                })

            # Enable path visibility toggle again after a short delay or operation completion
            turtle.ontimer(lambda: self.disable_delay('r_delay', True), 500)  # 500 milliseconds delay (adjust as needed)


    def toggle_path_visibility(self):
        self.lock_reset()
        if self.h_delay:
            self.h_delay = False  # Disable further toggles until function completes

            self.city_map.toggle_path_visibility(self.unlock_reset)

            # Enable path visibility toggle again after a short delay or operation completion
            turtle.ontimer(lambda: self.disable_delay('h_delay', True), 500)  # 500 milliseconds delay (adjust as needed)

        # self.unlock_reset()
        
    def disable_delay(self, key, value):
        setattr(self, key, value)
        

    def activate_player_mode(self):
            self.key_state.update({'x':False, 'q':False, 'r':False})
            self.display_status("Switching to Player Mode...")
            turtle.clearscreen()  # Clean up current turtle screen
            player_mode = PlayerMode()
            player_mode.run()