import turtle
import time
import copy
import threading

# Constants for the map
TILE_SIZE = 50
START_COLOR = "lime"
END_COLOR = "cyan"
ROAD_COLOR = "white"
BUILDING_COLOR = "grey"
CAR_COLOR = "black"
GRASS_COLOR = "green"
CIRCLE_THICKNESS = 3

class CityMap:
    def __init__(self, map_file, unlock_reset=None):
        self.map_file = map_file
        self.unlock_reset = unlock_reset

        if map_file == "map2.txt":
            self.read_playerMap()
        else:
            # Read the map and validate
            self.read_map()
        
        # Initialize turtle graphics
        self.turtle = turtle.Turtle()
        self.turtle.hideturtle()
        self.turtle.speed(0)  # Maximum speed for faster drawing
        self.path_turtle = turtle.Turtle()  # Separate turtle for drawing path circles
        self.path_turtle.hideturtle()

        # add tracer later
        self.path_turtle.speed(0)
        self.path_circles = []  # Add attribute to track path circles
        self.path_visible = True  # Track visibility state of the path
        self.road_tiles = []  # List to track white road tiles

        self.animation_running = True

        # Initialize the animation turtle
        self.animation_turtle = turtle.Turtle()
        self.animation_turtle.hideturtle()
        self.animation_turtle.speed(0)

        self.stop_event = threading.Event()
        self.animation_thread = None

        # Dictionary to track tile colors
        self.tile_colors = {}  # (x, y): color
        
        # Ensure start and end positions are correctly set
        if not self.start_position or not self.end_position:
            raise ValueError("Map must contain exactly one start ('s') and one end ('e') point.")
        

    def read_map(self):
        with open(self.map_file, 'r') as file:
            lines = [line.strip() for line in file.readlines()]

        # Ensure there is at least one row and one column
        if not lines or not lines[0]:
            raise ValueError("Map file is empty or malformed.")

        self.grid = lines
        self.rows = len(self.grid)
        self.cols = len(self.grid[0])

        # Ensure all rows have the same length
        if any(len(row) != self.cols for row in self.grid):
            raise ValueError("Inconsistent row lengths in the map file.")

        # Check for exactly one start ('s') and one end ('e') point
        start_count = sum(row.count('s') for row in self.grid)
        end_count = sum(row.count('e') for row in self.grid)

        if start_count != 1 or end_count != 1:
            raise ValueError("Map must contain exactly one start ('s') and one end ('e') point.")

        # Set start and end positions
        self.start_position = self.get_start_position()
        self.end_position = self.get_end_position()

    #PlayerMode readmap
    def read_playerMap(self):
        with open(self.map_file, 'r') as file:
            lines = [line.strip() for line in file.readlines()]

        # Ensure there is at least one row and one column
        if not lines or not lines[0]:
            raise ValueError("Map file is empty or malformed.")

        self.grid = [list(row) for row in lines]
        self.rows = len(self.grid)
        self.cols = len(self.grid[0])

        # Ensure all rows have the same length
        if any(len(row) != self.cols for row in self.grid):
            raise ValueError("Inconsistent row lengths in the map file.")

        # Check for exactly one start ('s') and one end ('e') point
        start_count = sum(row.count('s') for row in self.grid)
        end_count = sum(row.count('e') for row in self.grid)

        if start_count != 1 or end_count != 1:
            raise ValueError("Map must contain exactly one start ('s') and one end ('e') point.")

        # Set start and end positions
        self.start_position = self.get_start_position()
        self.end_position = self.get_end_position()

    def draw_tile(self, x, y, color):
        self.turtle.penup()
        self.turtle.goto(x, y)
        self.turtle.pendown()
        self.turtle.fillcolor(color)
        self.turtle.begin_fill()
        for _ in range(4):
            self.turtle.forward(TILE_SIZE)
            self.turtle.right(90)
        self.turtle.end_fill()

        # Update the tile color in the dictionary
        self.tile_colors[(x, y)] = color

    def draw_player_tile(self, x, y, color):
        self.animation_turtle.penup()
        self.animation_turtle.goto(x, y)
        self.animation_turtle.pendown()
        self.animation_turtle.fillcolor(color)
        self.animation_turtle.begin_fill()
        for _ in range(4):
            self.animation_turtle.forward(TILE_SIZE)
            self.animation_turtle.right(90)
        self.animation_turtle.end_fill()

    def draw_circle(self, x, y, circle_color):
        self.turtle.penup()
        self.turtle.goto(x, y - 15)
        self.turtle.pendown()
        self.turtle.pensize(CIRCLE_THICKNESS)
        self.turtle.color(circle_color)
        self.turtle.circle(15)
        self.turtle.pensize(1)  # Reset pen size to default

    def draw_path_circle(self, x, y):
        self.path_circles.append((x, y))  # Track the circle position
        self.path_turtle.penup()
        self.path_turtle.goto(x, y - 15)
        self.path_turtle.pendown()
        self.path_turtle.pensize(5)
        self.path_turtle.color('black')  # Set pen color to black for circumference
        self.path_turtle.fillcolor('yellow')  # Fill color set to yellow
        self.path_turtle.begin_fill()
        self.path_turtle.circle(15)
        self.path_turtle.end_fill()
        self.path_turtle.pensize(1)  # Reset pen size to default

    def erase_path_circles(self):
        self.path_turtle.clear()  # Clear all drawings made by the path turtle
        self.path_circles = []  # Clear the list after erasing

    def clear_path(self):
        self.erase_path_circles()
        # Redraw start and end circles
        if self.start_position:
            self.draw_tile(self.start_position[0] * TILE_SIZE - (self.cols // 2) * TILE_SIZE,
                           (self.rows // 2) * TILE_SIZE - self.start_position[1] * TILE_SIZE, START_COLOR)
            self.draw_circle(self.start_position[0] * TILE_SIZE - (self.cols // 2) * TILE_SIZE + TILE_SIZE // 2,
                             (self.rows // 2) * TILE_SIZE - self.start_position[1] * TILE_SIZE - TILE_SIZE // 2,
                             'green')
            self.draw_char_in_tile(self.start_position[0] * TILE_SIZE - (self.cols // 2) * TILE_SIZE + TILE_SIZE // 2,
                             (self.rows // 2) * TILE_SIZE - self.start_position[1] * TILE_SIZE - TILE_SIZE // 2,
                             's')
        if self.end_position:
            self.draw_tile(self.end_position[0] * TILE_SIZE - (self.cols // 2) * TILE_SIZE,
                           (self.rows // 2) * TILE_SIZE - self.end_position[1] * TILE_SIZE, END_COLOR)
            self.draw_circle(self.end_position[0] * TILE_SIZE - (self.cols // 2) * TILE_SIZE + TILE_SIZE // 2,
                             (self.rows // 2) * TILE_SIZE - self.end_position[1] * TILE_SIZE - TILE_SIZE // 2,
                             'blue')
            self.draw_char_in_tile(self.end_position[0] * TILE_SIZE - (self.cols // 2) * TILE_SIZE + TILE_SIZE // 2,
                             (self.rows // 2) * TILE_SIZE - self.end_position[1] * TILE_SIZE - TILE_SIZE // 2,
                             'e')

    def draw_map(self):
        start_x = -(self.cols // 2) * TILE_SIZE
        start_y = (self.rows // 2) * TILE_SIZE

        for y in range(self.rows):
            for x in range(self.cols):
                draw_x = start_x + x * TILE_SIZE
                draw_y = start_y - y * TILE_SIZE
                cell = self.grid[y][x]
                if cell == 'X':
                    self.draw_tile(draw_x, draw_y, BUILDING_COLOR)
                elif cell == '.':
                    if self.map_file == "map2.txt":
                        self.draw_tile(draw_x, draw_y, GRASS_COLOR)
                    else:
                        self.draw_tile(draw_x, draw_y, ROAD_COLOR)
                    self.road_tiles.append((draw_x, draw_y))  # Track the white tiles
                elif cell == 's':
                    self.draw_tile(draw_x, draw_y, START_COLOR)
                    self.draw_circle(draw_x + TILE_SIZE // 2, draw_y - TILE_SIZE // 2, 'green')
                    self.draw_char_in_tile(draw_x + TILE_SIZE // 2, draw_y - TILE_SIZE // 2, 's')
                elif cell == 'e':
                    self.draw_tile(draw_x, draw_y, END_COLOR)
                    self.draw_circle(draw_x + TILE_SIZE // 2, draw_y - TILE_SIZE // 2, 'blue')
                    self.draw_char_in_tile(draw_x + TILE_SIZE // 2, draw_y - TILE_SIZE // 2, 'e')
                elif cell == 'x':
                    self.draw_tile(draw_x, draw_y, ROAD_COLOR)
                    

    ##Player Mode Citymap Functions
    # New method for player mode with slower drawing
    def draw_map_player_mode(self):
        turtle.tracer(10, 20)  # Set tracer for slower drawing in player mode
        self.draw_map()
        turtle.update()  # Update turtle to reflect the drawing

    def start_moving_x_animation(self):
        start_rows = [self.rows - 3, self.rows - 5, self.rows - 7, self.rows - 9, self.rows - 11]
        start_col = self.cols - 2

        while not self.stop_event.is_set():
            for start_row in start_rows:
                row = start_row
                col = start_col

                for increment in range(12):
                    if self.stop_event.is_set():
                        return  # Exit if stop event is set

                    col = start_col - increment

                    if col < 0:
                        break

                    if self.grid[row][col] == 'x' or self.grid[row][col] == '.':
                        if self.stop_event.is_set():
                            return  # Exit if stop event is set
                        
                        x = (col * TILE_SIZE) - (self.cols // 2) * TILE_SIZE
                        y = (self.rows // 2) * TILE_SIZE - row * TILE_SIZE

                        if self.stop_event.is_set():
                            return  # Exit if stop event is set
                        
                        self.draw_player_tile(x, y, CAR_COLOR)

                        self.grid[row][col] = 'bird'

                        if self.stop_event.is_set():
                            return  # Exit if stop event is set
                        
                        time.sleep(0.5)

                        if self.stop_event.is_set():
                            return  # Exit if stop event is set
                        
                        self.draw_player_tile(x, y, ROAD_COLOR)

                        self.grid[row][col] = '.'
                        
                        if self.stop_event.is_set():
                            return  # Exit if stop event is set
                        
                    time.sleep(0.5)
                    if self.stop_event.is_set():
                        return  # Exit if stop event is set
                # Allow some time before moving to the next row
                time.sleep(1)



    def run_animation_in_background(self):
        self.stop_event.clear()  # Ensure the stop flag is cleared
        self.animation_thread = threading.Thread(target=self.start_moving_x_animation)
        self.animation_thread.start()

    def stop_animation(self):
        self.stop_event.set()  # Set the stop flag to stop the animation loop
        if self.animation_thread is not None:
            self.animation_thread.join()  # Wait for the thread to finish

        # Revert the 'bird' tile back to an 'x' tile
        for row in range(self.rows):
            for col in range(self.cols):
                if self.grid[row][col] == 'bird':
                    self.grid[row][col] = 'x'  # Revert to 'x' tile

        # Clear the animation turtle's drawing
        self.animation_turtle.clear()
        
            
    # def flash_road_tiles(self):
    #     while True:  # Infinite loop to keep the flashing effect
    #         # Turn all road tiles gray
    #         for (x, y) in self.road_tiles:
    #             self.draw_tile(x, y, BUILDING_COLOR)
    #         turtle.update()  # Update the screen with gray tiles
    #         time.sleep(5)  # Pause for 5 seconds

    #         # Turn all road tiles back to white
    #         for (x, y) in self.road_tiles:
    #             self.draw_tile(x, y, ROAD_COLOR)
    #         turtle.update()  # Update the screen with white tiles
    #         time.sleep(5)  # Pause for 5 second

    def turn_road_tiles_gray(self):
        # Turn all road tiles gray
        for (x, y) in self.road_tiles:
            self.draw_tile(x, y, BUILDING_COLOR)  # Assuming BUILDING_COLOR is gray
        turtle.update()  # Update the screen with gray tiles
    
    def turn_tile_white(self, drone_position):
        # Convert drone position to tile coordinates
        x, y = drone_position

        # Calculate the tile's top-left corner position
        tile_x = x * TILE_SIZE - (self.cols // 2) * TILE_SIZE
        tile_y = (self.rows // 2) * TILE_SIZE - y * TILE_SIZE

        # Check if the tile is gray before changing it to white
        if self.tile_colors.get((tile_x, tile_y)) == BUILDING_COLOR:
            # Draw the tile in white color
            self.draw_tile(tile_x, tile_y, ROAD_COLOR)

            # Optionally update the screen to reflect changes
            turtle.update()

    def draw_char_in_tile(self, x, y, char):
        self.turtle.penup()
        self.turtle.goto(x, y - TILE_SIZE // 3)  # Adjust vertical position for centering
        self.turtle.pendown()
        self.turtle.color("black")
        self.turtle.write(char, align="center", font=("Arial", 24, "normal"))

    def get_start_position(self):
        for y in range(self.rows):
            for x in range(self.cols):
                if self.grid[y][x] == 's':
                    return (x, y)
        return None

    def get_end_position(self):
        for y in range(self.rows):
            for x in range(self.cols):
                if self.grid[y][x] == 'e':
                    return (x, y)
        return None
    
    def hide_path_circles(self, unlock_reset=None):
        self.path_turtle.clear()  # Clear all drawings made by the path turtle
        self.unlock_reset = unlock_reset
        if self.unlock_reset:
            self.unlock_reset()

    def show_path_circles(self, unlock_reset=None):
        for x, y in self.path_circles:
            self.path_turtle.penup()
            self.path_turtle.goto(x, y - 15)
            self.path_turtle.pendown()
            self.path_turtle.pensize(5)
            self.path_turtle.color('black')  # Set pen color to black for circumference
            self.path_turtle.fillcolor('yellow')  # Fill color set to yellow
            self.path_turtle.begin_fill()
            self.path_turtle.circle(15)
            self.path_turtle.end_fill()
            self.path_turtle.pensize(1)  # Reset pen size to default

        self.unlock_reset = unlock_reset
        if self.unlock_reset:
            self.unlock_reset()
            
    def toggle_path_visibility(self, unlock_reset=None):
        if self.path_visible:
            self.hide_path_circles(unlock_reset)
        else:
            self.show_path_circles(unlock_reset)
        self.path_visible = not self.path_visible
