import sys
from activation import Activator

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python main.py <map_file>")
        sys.exit(1)
    map_file = sys.argv[1]
    activator = Activator(map_file)
    activator.run()
