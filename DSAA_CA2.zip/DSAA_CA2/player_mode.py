import turtle
import time, datetime, threading
from citymap import CityMap 
from drone import Drone 
from tkinter import simpledialog, Tk
import os

class PlayerMode:
    def __init__(self):
        self.map_files = ["map1.txt", "map2.txt"]
        self.titles=['Night Delivery','Obstacle Avoidance']
        self.current_map_index = 0
        self.city_map = CityMap(self.map_files[self.current_map_index])
        self.drone = None
        self.start_time = None
        self.best_time = float('inf')  # Initialize with infinity
        self.best_score = float('inf')  # Initialize with infinity
        self.score = 0
        self.trial_data = {map_file: [] for map_file in self.map_files}
        self.status_message = turtle.Turtle()
        self.status_message.hideturtle()
        self.status_message.penup()
        self.timer_display = turtle.Turtle()
        self.timer_display.hideturtle()
        self.timer_display.penup()
        self.title_display = turtle.Turtle()
        self.title_display.hideturtle()
        self.title_display.penup()
        self.score_display = turtle.Turtle()
        self.score_display.hideturtle()
        self.score_display.penup()
        self.best_time_display = turtle.Turtle()
        self.best_time_display.hideturtle()
        self.best_time_display.penup()
        self.best_score_display = turtle.Turtle()
        self.best_score_display.hideturtle()
        self.best_score_display.penup()
        self.timer_running = False
        self.last_key_time = time.time()
        self.time_list=[]
        self.key_delay = 0.5  # 600 ms delay to prevent spamming
        self.loading_map = False  # Flag to indicate if a map is being loaded
        self.player_name = self.prompt_for_name()  # Prompt for player name

        self.stop_thread = False
        #  # Start the flash road tiles function in a separate thread
        # self.flash_thread = threading.Thread(target=self.city_map.turn_road_tiles_gray)
        # self.flash_thread.daemon = True  # Allow the thread to exit when the main program exits
        # self.flash_thread.start()
        # Initialize the screen and key bindings
        self.setup_screen()

###################################################################################
# SETUP PLAYER MODE
###################################################################################
    def setup_screen(self):
        self.screen = turtle.Screen()
        self.screen.listen()

    def run(self):
        self.display_map()
        start_position = self.city_map.get_start_position()
        if start_position:
            self.drone = Drone(start_position, self.city_map)

            # Stop the previous thread if it exists
            if hasattr(self, 'update_thread') and self.update_thread.is_alive():
                self.stop_thread = True
                self.update_thread.join()  # Wait for the thread to finish

            # Reset the stop flag
            self.stop_thread = False
            
            if self.map_files[self.current_map_index] == "map1.txt":
                self.city_map.turn_road_tiles_gray()
                # Start the background thread for updating the tile
                self.update_thread = threading.Thread(target=self.update_tile_in_background)
                self.update_thread.daemon = True  # Daemonize thread to ensure it exits with the program
                self.update_thread.start()

            # Run the turtle graphics main loop
            turtle.mainloop()
        else:
            print("No start position found in the map.")

    def update_tile_in_background(self):
        while not self.stop_thread:
            # Get the current position of the drone
            current_position = self.drone.get_position()

            # Update the tile at the drone's current position to white
            self.city_map.turn_tile_white(current_position)

            # Delay to control the refresh rate, adjust as needed
            time.sleep(0.1)

    def load_map(self, map_index):
        self.city_map.stop_animation()
        if 0 <= map_index < len(self.map_files):
            self.loading_map = True
            self.setup_key_bindings()
            self.current_map_index = map_index
            turtle.clearscreen()
            self.reinitialize_turtles()

            self.city_map = CityMap(self.map_files[self.current_map_index])
            #Updated Code for Loading of map
            self.display_map()
            start_position = self.city_map.get_start_position()

            if start_position:
                self.drone = Drone(start_position, self.city_map)

                # Stop the previous thread if it exists
                if hasattr(self, 'update_thread') and self.update_thread.is_alive():
                    self.stop_thread = True
                    self.update_thread.join()  # Wait for the thread to finish

                # Reset the stop flag
                self.stop_thread = False

                if self.map_files[self.current_map_index] == "map1.txt":
                    self.city_map.turn_road_tiles_gray()
                    # Start the background thread for updating the tile
                    self.update_thread = threading.Thread(target=self.update_tile_in_background)
                    self.update_thread.daemon = True  # Daemonize thread to ensure it exits with the program
                    self.update_thread.start()
            else:
                print("No start position found in the map.")

            self.reset_map_data()
            self.timer_running = False
            self.update_timer_display()
            self.update_score_display()
            self.update_best_time_display()
            self.update_best_score_display()
            self.loading_map = False
            self.setup_key_bindings()


    def display_map(self):
        self.loading_map = True
        self.setup_key_bindings()
        self.city_map.draw_map_player_mode()

        if self.map_files[self.current_map_index] == "map2.txt":
            self.city_map.run_animation_in_background()

        self.display_title()
        self.update_timer_position()
        self.update_timer_display()
        self.update_score_display()
        self.update_best_time_display()
        self.update_best_score_display()
        self.display_status(f"Welcome pilot {self.player_name}, you are in charge!")
        self.loading_map = False
        self.setup_key_bindings()


###################################################################################
# PROMPT FOR PILOT NAME
###################################################################################

    def prompt_for_name(self):
        root = Tk()
        root.withdraw()
        name = None
        while not name or name.strip() == "":
            name = simpledialog.askstring("Enter Name", "Please enter your name:")
            if not name or name.strip() == "":
                simpledialog.messagebox.showwarning("Invalid Input", "Name cannot be empty. Please enter a valid name.")
        name = name.upper()
        root.destroy()
        return name

###################################################################################
# SETUP KEYBINDS FOR PLAYER MODE
###################################################################################
    def setup_key_bindings(self):
        if not self.loading_map:
            self.screen.onkey(lambda: self.check_key("w", self.drone.move_up), "w")
            self.screen.onkey(lambda: self.check_key("a", self.drone.move_left), "a")
            self.screen.onkey(lambda: self.check_key("s", self.drone.move_down), "s")
            self.screen.onkey(lambda: self.check_key("d", self.drone.move_right), "d")
            self.screen.onkey(lambda: self.check_key("1", self.load_map, 0), "1")
            self.screen.onkey(lambda: self.check_key("2", self.load_map_and_disable_1, 1), "2")
            # self.screen.onkey(lambda: self.check_key("3", self.load_map, 2), "3")
            self.screen.onkey(lambda: self.check_key("r", self.reset_drone), "r")
            self.screen.onkey(self.quit_application, "q")
        else:
            # Unbind keys if the map is loading
            self.screen.onkey(None, "w")
            self.screen.onkey(None, "a")
            self.screen.onkey(None, "s")
            self.screen.onkey(None, "d")
            self.screen.onkey(None, "1")
            self.screen.onkey(None, "2")
            # self.screen.onkey(None, "3")
            self.screen.onkey(None, "r")
            self.screen.onkey(None, "q")

    def load_map_and_disable_1(self, map_index):
        self.load_map(map_index)
        self.screen.onkey(None, "1")  # Disable the "1" key after "2" is pressed

    def check_key(self, key, function, *args):
        current_time = time.time()
        if current_time - self.last_key_time >= self.key_delay:
            if key in ["w", "a", "s", "d"]:
                # Use self.screen.ontimer to avoid immediate execution
                self.screen.ontimer(lambda: self.process_key(key, function, *args), 0)
            else:
                function(*args)
            self.last_key_time = current_time

    def process_key(self, key, function, *args):
        # Wrap Turtle graphics operations in a try-except block
        try:
            function(*args)
            self.display_status('YOU ARE IN CONTROL...')
            self.start_timer()
            self.increment_score()
            self.display_score()
            self.check_end_tile()
        except turtle.TurtleGraphicsError as e:
            print(f"Turtle graphics error: {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")



    def reset_drone(self):
        start_position = self.city_map.get_start_position()
        if start_position:
            self.drone.reset_position(start_position)
            self.drone.turtle.setheading(90)
            self.display_status('DRONE RESETTED')

            self.score = 0
            self.update_score_display()

            self.stop_timer()
            self.timer_display.clear()
            self.update_timer_display()
            self.update_timer_position()
            self.setup_key_bindings()

            if self.map_files[self.current_map_index] == "map1.txt":
                self.city_map.turn_road_tiles_gray()
            elif self.map_files[self.current_map_index] == "map2.txt":
                self.city_map.stop_animation()
                time.sleep(2)
                self.city_map.run_animation_in_background()



    def check_end_tile(self):
        if self.drone.position == self.city_map.get_end_position():
            self.stop_timer()
            self.record_trial_data()
            self.update_best_time()
            self.update_best_score()
            self.freeze_movement()
            if self.map_files[self.current_map_index] == "map2.txt":
                self.city_map.stop_animation()
                time.sleep(2)
                self.city_map.run_animation_in_background()



    def freeze_movement(self):
        self.screen.onkey(None, "w")
        self.screen.onkey(None, "a")
        self.screen.onkey(None, "s")
        self.screen.onkey(None, "d")

####################################################################################
#  BASIC DISPLAY FUNCTIONS
####################################################################################

    def display_title(self):
        titles = {
            "map1.txt": "Night Delivery",
            "map2.txt": "Obstacle Avoidance"
            # "citymap001.txt": "Advanced Level"
        }
        level_title = titles.get(self.map_files[self.current_map_index], "Unknown Level")
        self.title_display.clear()
        self.title_display.goto(-self.city_map.cols * 25, self.city_map.rows * 25 + 60)
        self.title_display.write(level_title, font=("Arial", 16, "bold"))

    def display_status(self, message):
        TILE_SIZE = 50
        grid_width = self.city_map.cols * TILE_SIZE
        grid_height = self.city_map.rows * TILE_SIZE

        status_x = -grid_width // 2
        status_y = grid_height // 2 + 47.5

        self.status_message.clear()
        self.status_message.goto(status_x, status_y)
        self.status_message.write(message, font=("Arial", 12, "normal"))

###################################################################################
# TIMER AND SCORE DISPLAY AND TRACKER
###################################################################################

# Timer below 
###################################################################################

    def start_timer(self):
        if not self.timer_running:
            self.start_time = time.time()
            self.timer_running = True
            self.display_timer()

    def stop_timer(self):
        self.timer_running = False

    def update_timer_position(self):
        TILE_SIZE = 50
        grid_width = self.city_map.cols * TILE_SIZE
        grid_height = self.city_map.rows * TILE_SIZE

        status_x = -grid_width // 2
        status_y = grid_height // 2 + 40

        self.status_message.goto(status_x, status_y)
        self.timer_display.goto(status_x, status_y - 10 if self.status_message.isvisible() else status_y - 10)
        self.best_time_display.goto(status_x+ 200, status_y - 10 if self.status_message.isvisible() else status_y - 10)
        self.score_display.goto(status_x, status_y -30 if self.status_message.isvisible() else status_y - 30)
        self.best_score_display.goto(status_x+ 200, status_y - 30 if self.status_message.isvisible() else status_y - 30)

    def display_timer(self):
        if self.timer_running:
            elapsed_time = time.time() - self.start_time
            minutes = int(elapsed_time // 60)
            seconds = int(elapsed_time % 60)
            milliseconds = int((elapsed_time % 1) * 1000) // 10
            self.time_list.append(elapsed_time)
            self.timer_display.clear()
            self.timer_display.write(f"Time: {minutes:02}:{seconds:02}:{milliseconds:02}", font=("Arial", 14, "normal"))
            turtle.ontimer(self.display_timer, 100)

    def update_timer_display(self):
        self.timer_display.clear()
        self.timer_display.write("Time: 00:00:00", font=("Arial", 14, "normal"))

    def update_best_time(self):
        elapsed_time = self.time_list[-1]
        if elapsed_time < self.best_time:
            self.best_time = elapsed_time
            self.update_best_time_display()

    def update_best_time_display(self):
        if self.best_time == float('inf'):
            best_time_str = "Best Time: --:--:--"
        else:
            minutes = int(self.best_time // 60)
            seconds = int(self.best_time % 60)
            milliseconds = int((self.best_time % 1) * 1000) // 10
            best_time_str = f"Best Time: {minutes:02}:{seconds:02}:{milliseconds:02}"   
        self.best_time_display.clear()
        self.best_time_display.write(best_time_str, font=("Arial", 14, "normal"))


# Track steps below 
###################################################################################

    def display_score(self):
        self.score_display.clear()
        self.score_display.write(f"Score: {self.score}", font=("Arial", 14, "normal"))

    def update_score_display(self):
        self.score_display.clear()
        self.score_display.write(f"Score: {self.score}", font=("Arial", 14, "normal"))

    def increment_score(self):
        self.score += 1

    def update_best_score(self):
        if self.score < self.best_score:
            self.best_score = self.score
            self.update_best_score_display()

    def update_best_score_display(self):
        best_score_str = f"Best Score: {self.best_score}" if self.best_score != float('inf') else "Best Score: -"
        self.best_score_display.clear()
        self.best_score_display.write(best_score_str, font=("Arial", 14, "normal"))

    def reinitialize_turtles(self):
        self.status_message.clear()
        self.timer_display.clear()
        self.score_display.clear()
        self.best_time_display.clear()
        self.best_score_display.clear()

####################################################################################
#  RECORDING TRIAL DATA WITH REPORT GENERATION
####################################################################################

    def record_trial_data(self):
        elapsed_time = time.time() - self.start_time
        current_map = self.map_files[self.current_map_index]
        self.trial_data[current_map].append({
            "time": elapsed_time,
            "score": self.score
        })

    def reset_map_data(self):
        self.best_time = float('inf')
        self.best_score = float('inf')
        self.score = 0
        self.update_timer_display()
        self.update_score_display()
        self.update_best_time_display()
        self.update_best_score_display()

    def generate_final_report(self):
        # Create a directory for the player if it doesn't exist
        player_folder = self.player_name
        if not os.path.exists(player_folder):
            os.makedirs(player_folder)

        # Create a timestamped report filename
        report_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        report_filename = f"{self.player_name}_{report_time}_report.txt"
        report_path = os.path.join(player_folder, report_filename)

        try:
            with open(report_path, "w") as file:
                current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                file.write("Pilot Flying Performance Report\n")
                report = f"Report generated on: {current_time}" 
                file.write(f'{report:^12}')
                file.write("\n")

                for map_file, title in zip(self.map_files, self.titles):
                    file.write(f"+{'-' * 30}+\n")
                    file.write(f"| {'Map: ' + title.replace('.txt', '').title():^28} |\n")
                    file.write(f"+{'-' * 30}+\n")
                    file.write(f"| {'TRIAL':^8} | {'TIME':^8} | {'SCORE':^6} |\n")
                    file.write(f"+{'-' * 30}+\n")

                    trials = self.trial_data.get(map_file, [])
                    for i, trial in enumerate(trials):
                        elapsed_time = trial["time"]
                        score = trial["score"]
                        minutes = int(elapsed_time // 60)
                        seconds = int(elapsed_time % 60)
                        milliseconds = int((elapsed_time % 1) * 1000) // 10

                        trial_label = f"TRIAL {i + 1}"
                        file.write(f"| {trial_label:^8} | {minutes:02}:{seconds:02}:{milliseconds:02} | {score:^6} |\n")

                    if trials:
                        best_time = min((trial["time"] for trial in trials), default=float('inf'))
                        best_score = min((trial["score"] for trial in trials), default=float('inf'))

                        best_minutes = int(best_time // 60) if best_time != float('inf') else '--'
                        best_seconds = int(best_time % 60) if best_time != float('inf') else '--'
                        best_milliseconds = int((best_time % 1) * 1000) // 10 if best_time != float('inf') else '--'

                        file.write(f"+{'-' * 30}+\n")
                        file.write(f"| {'BEST':^8} | {f'{best_minutes:02}:{best_seconds:02}:{best_milliseconds:02}' if best_time != float('inf') else '--:--:--':^8} | {best_score if best_score != float('inf') else '--':^6} |\n")
                    else:
                        file.write(f"+{'-' * 30}+\n")
                        file.write(f"| {'BEST':^8} | {'--:--:--':^8} | {'--':^6} |\n")

                    file.write(f"+{'-' * 30}+\n\n")
        except IOError as e:
            print(f"Error writing report: {e}")

    def quit_application(self):
        self.city_map.stop_animation()
        self.generate_final_report()
        turtle.bye()  # Quit the turtle graphics window

if __name__ == "__main__":
    player_mode = PlayerMode()
    player_mode.run()
